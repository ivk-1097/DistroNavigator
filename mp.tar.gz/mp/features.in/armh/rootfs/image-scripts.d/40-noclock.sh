#!/bin/sh
echo 'HWCLOCK_SET_TIME_AT_START=false' >> /etc/sysconfig/clock
